TITLE: Taste - Free Bootstrap 4 Template
AUTHOR: Free-Template.co
LICENSE: Under Creative Commons 3.0 (free-template.co/license)
Twitter: https://twitter.com/Free_Templateco


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Google Maps
https://maps.google.com/

Icomoon
https://icomoon.io/app/

Open Iconic
https://useiconic.com/open/

Demo Images
https://unsplash.com

Waypoints
https://imakewebthings.com/waypoints/

Owl Carousel 2
https://owlcarousel2.github.io/OwlCarousel2/

AnimateNumber
aishek.github.io/jquery-animateNumber/

DatePicker
http://eternicode.github.io/bootstrap-datepicker/

TimePicker
http://jonthornton.github.com/jquery-timepicker/
